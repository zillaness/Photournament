# Image-generation concept prompts

The raster generations were used only to explore directions. Every shipped mark
and lockup was redrawn as deterministic SVG geometry.

## Initial exploration

> Explore four original minimalist logomark variations for “Photournament,” a
> desktop photography-culling app that reduces a grid of photos to selected
> finalists and then ranks them head-to-head. Build from the app’s existing
> visual seed: a 3-by-3 contact-sheet grid with one selected cell. Subtly explore
> selection, narrowing, bracket progression, or a camera/viewfinder without
> becoming literal or busy. Produce a precise vector-logo study with flat
> geometric shapes, strong silhouette, consistent optical spacing, and
> legibility at 16 px. Use achromatic near-black, mid-gray, and near-white, with
> at most one restrained desaturated blue accent. No gradients, mockups, 3D,
> shadows, text, letters, camera clip-art, trophies, generic aperture icons, or
> watermarks.

Reference: `docs/screens/01_entry.png`, used for palette, restraint, and continuity.

## Bracket and filtering exploration

> Create exactly two minimalist horizontal vector-style symbol explorations for
> Photournament. Concept A starts with a compact 3-by-3 photo grid on the left,
> then shows selected frames entering a clean pairwise tournament bracket that
> narrows to one winning square on the right. The early stage must visibly be
> the nine-square grid, not nine loose bracket nodes. Concept B starts with a
> complete 3-by-3 photo grid and progressively filters it from left to right, as
> if unselected cells are clean geometric fragments crumbling or blowing away
> while one selected square remains. Keep the effect controlled and logo-like,
> not smoky or illustrative. Use flat geometric modules on a dark neutral
> background, with mid-gray cells and a near-white winner. No gradients,
> shadows, 3D, text, letters, camera, aperture, trophy, watermark, realistic
> dust, smoke, motion blur, or overly complex bracket detail.

Reference: `docs/screens/01_entry.png`, used for palette and product continuity.
