# Product and visual context

Photournament is a local-first photography culling app. A photographer begins
with a group of images, reduces that group through quota-based grid passes, and
then compares finalists head-to-head in a tournament bracket.

The existing interface is restrained and dark so UI colors do not influence
photo judgment. That led to an achromatic identity built from the app’s most
recognizable interaction: a three-by-three contact sheet with one selected
frame.

The logo exploration focused on three questions:

1. Can the nine-cell mark communicate selection without becoming literal?
2. Can repeated filtering be encoded inside the mark rather than appended as a
   wide diagram?
3. How much recursion survives at favicon size?

The final responsive answer keeps the normal nine-cell silhouette at every
size. Large versions use deep top-left recursion. Small favicons reduce that to
one explicit nested grid with a visible micro-center, preserving the idea while
protecting legibility.
