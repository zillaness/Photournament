# Photournament square-corner comparison

This variation removes corner rounding from the recursive mark, favicon cells,
and app-icon background. The geometry, spacing, palette, recursion path, and
wordmark are otherwise unchanged.

The 16, 32, and 48 px favicon PNGs are independently pixel-tuned rather than
automatic reductions. Each keeps the top-left nested grid and its white center.

The square treatment is especially effective at 32 and 48 px: it produces a
cleaner contact-sheet character and gives the small cells more usable area. At
16 px, the recursive detail necessarily reduces to a compact three-by-three
pixel field.

This is a comparison set only; it has not replaced the packaged final identity
or repository assets.
