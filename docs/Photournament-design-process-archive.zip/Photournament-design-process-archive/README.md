# Photournament identity: the winnowing archive

This archive preserves the complete logo exploration—including the directions
that were not selected—as a record of the same narrowing process the product
performs. A broad field of candidates becomes a smaller set of contenders, then
one final identity.

The selected result is the nine-cell mark paired with the `Photournament`
wordmark. Its top-left source cell recursively contains another nine-cell
selection: each nested grid selects its center while the next round continues
through the top-left cell. This adds the idea of repeated culling without
abandoning the clean primary mark.

## Iteration map

| Stage | Direction | Outcome |
|---|---|---|
| 00 | Product brief, visual context, and prompts | Inputs |
| 01 | Generated shape explorations | Reference studies |
| 02 | Simple nine-cell primary | Core visual language retained |
| 03 | Grid-to-bracket and wind-filter metaphors | Clear process, too wide for a primary mark |
| 04 | Full and deep fractals | Compelling large artwork, too dense for daily use |
| 05 | Four-corner and inverted-center fractals | Stronger restraint, still visually assertive |
| 06 | Subtle fractal treatments across the primary | Useful bridge toward the final direction |
| 07 | One recursive source cell and white-pick tests | Final concept narrowed to top-left recursion |
| 08 | Final responsive identity | Selected |
| 09 | Rounded-versus-square small-icon study | Square corners selected for favicons only |
| 09 | Comparison sheets | Review record |
| 10 | Repository integration | Ready-to-use files and rebuilt app |

“Rejected” here means *not selected as the primary*, not discarded. The wider
filter graphics and deeper fractals remain useful as explanatory artwork,
banners, editorial graphics, or a visual account of the design process.

## File conventions

- SVG is the editable, scalable source for marks and lockups.
- PNG is supplied for quick use and review.
- The final favicon has square-corner, pixel-tuned 16, 32, and 48 px versions
  plus a multi-size ICO.
- The logo, large mark, and 180/192/512 px app icons retain rounded corners and
  deeper recursion.
- The repository-ready folder includes the integrated source and rebuilt
  standalone HTML files.

## Palette

- Background: `#171717`
- Grid cells: `#474747`
- Selected frame: `#F3F3F3`
- UI accent, not used in the mark: `#759DC3`

The achromatic logo avoids casting color beside photographs.
